# PintaPro
Calculadora web de presupuestos para Pinturas Decodl SL.

## Publicarla gratis en GitHub Pages
Sube `index.html`, `style.css` y `app.js` a la raíz del repositorio. Después activa GitHub Pages desde Settings → Pages.

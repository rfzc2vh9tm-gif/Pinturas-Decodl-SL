const tipo=document.getElementById('tipo');
tipo.addEventListener('change',()=>{const rod=tipo.value==='rodapie';document.getElementById('metrosWrap').classList.toggle('hide',rod);document.getElementById('linealesWrap').classList.toggle('hide',!rod)});
function calcular(){
 const t=tipo.value, m=Number(document.getElementById('metros').value), ml=Number(document.getElementById('lineales').value), km=Number(document.getElementById('km').value);
 let txt='';
 if(t==='rodapie'){
   if(!ml){txt='Introduce los metros lineales.'}
   else {let min=ml>=50?12:25,max=ml>=50?15:40;txt=`Estimación: <b>${(ml*min).toFixed(0)}–${(ml*max).toFixed(0)} €</b> (${min}–${max} €/ml).`}
 } else {
   if(!m){txt='Introduce los metros cuadrados.'}
   else {let min=t==='paredes'?15:45,max=t==='paredes'?30:60;txt=`Estimación: <b>${(m*min).toFixed(0)}–${(m*max).toFixed(0)} €</b> (${min}–${max} €/m²).`}
 }
 if(km>=50) txt += '<br><br>⚠️ A partir de 50 km se puede añadir el tiempo de desplazamiento.';
 const r=document.getElementById('resultado');r.innerHTML=txt;r.style.display='block';
}